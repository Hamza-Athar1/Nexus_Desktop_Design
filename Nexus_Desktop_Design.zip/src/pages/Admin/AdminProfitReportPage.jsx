import React, { useState, useEffect, useMemo } from 'react';
import { useOutletContext } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
  TrendingUp,
  ShoppingCart,
  BarChart3,
  Activity,
  Calendar,
  ChevronDown,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';

import { getProfitAnalysisReport } from '../../lib/reportService.js';

export default function AdminProfitReportPage() {
  const { setHeaderDetails } = useOutletContext() || {};
  const { user } = useAuth();

  const [selectedPeriod, setSelectedPeriod] = useState('This Week');
  const [filterOpen, setFilterOpen] = useState(false);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [profitAnalysisData, setProfitAnalysisData] = useState([]);
  const [_isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (setHeaderDetails) {
      setHeaderDetails({
        title: user?.businessName?.toUpperCase() || 'IMTIAZ SUPER MARKET',
        subtitle: null,
      });
    }
  }, [setHeaderDetails, user]);

  useEffect(() => {
    async function loadData() {
      setIsLoading(true);
      try {
        const params = { period: selectedPeriod, startDate, endDate };
        const profitRes = await getProfitAnalysisReport(params);
        if (profitRes.ok && Array.isArray(profitRes.data?.profitAnalysis)) {
          setProfitAnalysisData(profitRes.data.profitAnalysis);
        }
      } catch {
        setProfitAnalysisData([]);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();
  }, [selectedPeriod, startDate, endDate]);

  const totalRevenue = useMemo(() => {
    return profitAnalysisData.reduce((sum, p) => sum + Number(p.revenue || 0), 0);
  }, [profitAnalysisData]);

  const totalCost = useMemo(() => {
    return profitAnalysisData.reduce((sum, p) => sum + Number(p.cost || 0), 0);
  }, [profitAnalysisData]);

  const totalProfit = useMemo(() => {
    return profitAnalysisData.reduce((sum, p) => sum + Number(p.profit || 0), 0);
  }, [profitAnalysisData]);

  const profitMarginPercent = totalRevenue > 0 ? ((totalProfit / totalRevenue) * 100).toFixed(2) : '0.00';

  const metricsData = [
    {
      label: 'TOTAL REVENUE',
      value: `Rs ${totalRevenue.toLocaleString()}`,
      icon: TrendingUp,
      iconBg: 'bg-[#fde8e4] text-[#8b1e10]',
      statusPill: { text: 'Live Sales', bg: 'bg-[#fde8e4] text-[#8b1e10] border-[#f8b4ab]' },
    },
    {
      label: 'TOTAL COST',
      value: `Rs ${totalCost.toFixed(2)}`,
      icon: ShoppingCart,
      iconBg: 'bg-[#fef7df] text-[#c28e0e]',
      statusPill: { text: 'Item COGS', bg: 'bg-[#fef7df] text-[#c28e0e] border-[#fde047]' },
    },
    {
      label: 'TOTAL PROFIT',
      value: `Rs ${totalProfit.toFixed(2)}`,
      icon: BarChart3,
      iconBg: 'bg-[#fef3d6] text-[#b45309]',
      statusPill: { text: 'Net Margin', bg: 'bg-[#fef3d6] text-[#b45309] border-[#fde047]' },
    },
    {
      label: 'PROFIT MARGIN',
      value: `${profitMarginPercent}%`,
      icon: Activity,
      iconBg: 'bg-[#fde8e4] text-[#8b1e10]',
      statusPill: { text: 'Calculated', bg: 'bg-[#fde8e4] text-[#8b1e10] border-[#f8b4ab]' },
    },
  ];

  const memoizedBarData = profitAnalysisData;
  const memoizedLineData = profitAnalysisData;

  return (
    <div className="flex flex-col gap-6 w-full pb-12">
      {/* ── Top Title & Controls Header ── */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl lg:text-4xl font-black text-[#0c3818] tracking-tight">
            Profit Report
          </h1>
          <p className="text-base sm:text-lg font-bold text-[#607455] mt-1">
            Profit and financial performance
          </p>
        </div>

        {/* Filter Controls (Dropdown + Start Date + End Date) */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Period Select Dropdown */}
          <div className="relative">
            <button
              onClick={() => setFilterOpen(!filterOpen)}
              className="flex items-center gap-2.5 px-4 py-2.5 bg-white border border-[#0c3818]/30 text-[#0c3818] text-sm font-bold rounded-xl hover:bg-[#efeacb]/30 transition duration-150 cursor-pointer shadow-xs min-w-[130px] justify-between"
            >
              <span>{selectedPeriod}</span>
              <ChevronDown size={16} className="text-[#0c3818]/70" />
            </button>

            {filterOpen && (
              <div className="absolute right-0 top-full mt-1 bg-white border border-[#0c3818]/20 rounded-xl shadow-lg z-30 w-36 overflow-hidden flex flex-col divide-y divide-[#0c3818]/10 text-left">
                {['Today', 'This Week', 'This Month', 'This Year'].map((opt) => (
                  <button
                    key={opt}
                    onClick={() => {
                      setSelectedPeriod(opt);
                      setFilterOpen(false);
                    }}
                    className="px-4 py-2.5 text-left text-xs font-bold text-[#0c3818] hover:bg-[#efeacb] transition duration-150 cursor-pointer"
                  >
                    {opt}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Start Date */}
          <div className="relative w-full sm:w-44">
            <input
              type="text"
              placeholder="Start Date"
              onFocus={(e) => (e.target.type = 'date')}
              onBlur={(e) => {
                if (!e.target.value) e.target.type = 'text';
              }}
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full bg-white border border-[#0c3818]/30 rounded-xl px-4 py-2.5 pr-10 text-sm font-semibold text-[#0c3818] placeholder-[#607455]/70 focus:outline-none focus:border-[#0c3818] shadow-xs transition"
            />
            <Calendar
              size={18}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[#0c3818]/60 pointer-events-none"
            />
          </div>

          {/* End Date */}
          <div className="relative w-full sm:w-44">
            <input
              type="text"
              placeholder="End Date"
              onFocus={(e) => (e.target.type = 'date')}
              onBlur={(e) => {
                if (!e.target.value) e.target.type = 'text';
              }}
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full bg-white border border-[#0c3818]/30 rounded-xl px-4 py-2.5 pr-10 text-sm font-semibold text-[#0c3818] placeholder-[#607455]/70 focus:outline-none focus:border-[#0c3818] shadow-xs transition"
            />
            <Calendar
              size={18}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[#0c3818]/60 pointer-events-none"
            />
          </div>
        </div>
      </div>

      {/* ── 4 Top Summary Cards ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {metricsData.map((item, idx) => {
          const IconComponent = item.icon;
          return (
            <div
              key={idx}
              className="border-2 border-[#0c3818]/25 rounded-2xl p-4 sm:p-5 bg-gradient-to-r from-white via-[#fcfbf4] to-white flex items-center justify-between shadow-xs hover:border-[#0c3818]/45 hover:shadow-md transition-all duration-200 relative overflow-hidden"
            >
              {/* Icon Container */}
              <div className={`w-12 h-12 sm:w-14 sm:h-14 rounded-2xl flex items-center justify-center shrink-0 shadow-xs ${item.iconBg}`}>
                <IconComponent className="w-6 h-6 sm:w-7 sm:h-7 stroke-[2.2]" />
              </div>

              {/* Middle Gap Visual Enhancer: Decorative Gradient Accent Line & Status Pill */}
              <div className="flex-1 flex items-center gap-2 mx-3 min-w-0">
                <div className="flex-1 h-[2px] bg-gradient-to-r from-[#0c3818]/20 via-[#0c3818]/8 to-transparent rounded-full" />
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border shadow-2xs whitespace-nowrap hidden xl:inline-block ${item.statusPill.bg}`}>
                  {item.statusPill.text}
                </span>
                <div className="flex-1 h-[2px] bg-gradient-to-r from-transparent via-[#0c3818]/8 to-[#0c3818]/20 rounded-full" />
              </div>

              {/* Right Stats Text */}
              <div className="flex flex-col text-right min-w-0 shrink-0">
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-[#607455]">
                  {item.label}
                </span>
                <span className="text-xl sm:text-2xl lg:text-3xl font-black text-[#0c3818] tracking-tight mt-0.5 truncate">
                  {item.value}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* ── Main Layout: Profit Bar Chart (Left) & Revenue vs Profit Multi-Line Chart (Right) ── */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* Left Card: Profit (Bar Chart) */}
        <div className="lg:col-span-6 border-2 border-[#0c3818]/25 rounded-2xl md:rounded-3xl p-6 bg-[#f9f7ea]/80 backdrop-blur-xs shadow-xs flex flex-col justify-between gap-6">
          <h2 className="text-xl sm:text-2xl font-black text-[#0c3818] tracking-tight">
            Profit
          </h2>

          <div className="h-[280px] sm:h-[320px] w-full text-xs">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={memoizedBarData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <CartesianGrid stroke="#0c3818" strokeOpacity={0.06} strokeDasharray="3 3" vertical={false} />
                <XAxis
                  dataKey="name"
                  stroke="#0c3818"
                  fontSize={12}
                  fontWeight="bold"
                  tickLine={false}
                  axisLine={{ stroke: '#0c3818', strokeOpacity: 0.2 }}
                />
                <YAxis
                  stroke="#0c3818"
                  fontSize={12}
                  fontWeight="bold"
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(val) => (val === 0 ? '0' : `${val / 1000}K`)}
                  domain={[0, 1000000]}
                  ticks={[0, 200000, 400000, 600000, 800000, 1000000]}
                />
                <Tooltip
                  cursor={{ fill: '#0c3818', fillOpacity: 0.05 }}
                  contentStyle={{
                    backgroundColor: '#efeacb',
                    borderColor: '#0c3818',
                    borderRadius: '12px',
                    color: '#0c3818',
                    fontWeight: 'bold',
                  }}
                  formatter={(val) => [`PKR ${val.toLocaleString()}`, 'Profit']}
                />
                <Bar
                  dataKey="profit"
                  fill="#0c3818"
                  radius={[4, 4, 0, 0]}
                  maxBarSize={48}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right Card: REVENUE VS PROFIT (Multi-Line Chart) */}
        <div className="lg:col-span-6 border-2 border-[#0c3818]/25 rounded-2xl md:rounded-3xl p-6 bg-[#f9f7ea]/80 backdrop-blur-xs shadow-xs flex flex-col justify-between gap-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl sm:text-2xl font-black text-[#0c3818] tracking-tight uppercase">
              REVENUE VS PROFIT
            </h2>

            {/* Custom Legend Matching Screenshot */}
            <div className="flex items-center gap-4 text-xs font-black select-none">
              <div className="flex items-center gap-1.5 text-[#16a34a]">
                <span className="w-2.5 h-2.5 rounded-full bg-[#16a34a]" />
                <span>REVENUE</span>
              </div>
              <div className="flex flex-row items-center gap-1.5 text-[#8b1e10]">
                <span className="w-2.5 h-2.5 rounded-full bg-[#8b1e10]" />
                <span>PROFIT</span>
              </div>
            </div>
          </div>

          <div className="h-[280px] sm:h-[320px] w-full text-xs">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={memoizedLineData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <CartesianGrid stroke="#0c3818" strokeOpacity={0.06} strokeDasharray="3 3" vertical={false} />
                <XAxis
                  dataKey="name"
                  stroke="#0c3818"
                  fontSize={12}
                  fontWeight="bold"
                  tickLine={false}
                  axisLine={{ stroke: '#0c3818', strokeOpacity: 0.2 }}
                />
                <YAxis
                  stroke="#0c3818"
                  fontSize={12}
                  fontWeight="bold"
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(val) => (val === 0 ? '0' : `${val / 1000}K`)}
                  domain={[0, 1000000]}
                  ticks={[0, 200000, 400000, 600000, 800000, 1000000]}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#efeacb',
                    borderColor: '#0c3818',
                    borderRadius: '12px',
                    color: '#0c3818',
                    fontWeight: 'bold',
                  }}
                  formatter={(val, name) => [`PKR ${val.toLocaleString()}`, name.toUpperCase()]}
                />
                {/* Profit Line (Dark Red) */}
                <Line
                  type="monotone"
                  dataKey="profit"
                  stroke="#8b1e10"
                  strokeWidth={3}
                  dot={{ r: 5, fill: '#8b1e10', stroke: '#8b1e10' }}
                  activeDot={{ r: 7 }}
                />
                {/* Revenue Line (Green) */}
                <Line
                  type="monotone"
                  dataKey="revenue"
                  stroke="#16a34a"
                  strokeWidth={3}
                  dot={{ r: 5, fill: '#16a34a', stroke: '#16a34a' }}
                  activeDot={{ r: 7 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>
    </div>
  );
}
