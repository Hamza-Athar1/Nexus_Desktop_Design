import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Trash2, Barcode } from 'lucide-react';
import { apiFetchJson } from '../../lib/api.js';
import { createSale } from '../../lib/salesService.js';
import { scanBarcodeApi } from '../../lib/inventoryService.js';
import ViewInvoiceModal from '../../components/Admin/ViewInvoiceModal.jsx';
import BarcodeScannerModal from '../../components/BarcodeScannerModal.jsx';

function POSClock() {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formattedDateTime = useMemo(() => {
    const optionsDate = { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' };
    const optionsTime = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true };
    const dateStr = currentTime.toLocaleDateString('en-US', optionsDate);
    const timeStr = currentTime.toLocaleTimeString('en-US', optionsTime);
    return `${dateStr} ${timeStr}`;
  }, [currentTime]);

  return <p className="text-sm font-bold text-[#0d3410]/95 font-mono">{formattedDateTime}</p>;
}

import { getCustomers } from '../../lib/customerService.js';
import { useAuth } from '../../context/AuthContext';

export default function POSSystemPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const receiptSettings = user?.receiptSettings || {};
  const displayShopName = receiptSettings.shopName || user?.businessName || 'Imtiaz Super Market';
  const displayLogo = receiptSettings.logoUrl || '/Nexus_superadmin.png';
  const [products, setProducts] = useState([]);
  const [isLoadingProducts, setIsLoadingProducts] = useState(false);
  const [fetchError, setFetchError] = useState(null);

  // Real Customers State
  const [customerList, setCustomerList] = useState([{ id: null, name: 'Walk-in Customer' }]);
  const [activeCustomerIndex, setActiveCustomerIndex] = useState(0);

  // Cart / Invoice state per customer
  const [carts, setCarts] = useState({
    0: [],
  });

  // Inputs per customer
  const [laborCharges, setLaborCharges] = useState({ 0: 0 });
  const [paidAmounts, setPaidAmounts] = useState({ 0: '' });

  // Invoice numbers / checkout state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [_checkoutError, setCheckoutError] = useState(null);
  const [completedSale, setCompletedSale] = useState(null);

  // Search input state
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchResults, setShowSearchResults] = useState(false);

  // Scan simulation & camera scanner state
  const [scanLaserActive, setScanLaserActive] = useState(false);
  const [lastScannedItem, setLastScannedItem] = useState(null);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [barcodeScanError, setBarcodeScanError] = useState(null);
  const [barcodeScanSuccess, setBarcodeScanSuccess] = useState(null);
  const [manualBarcode, setManualBarcode] = useState('');

  // Fetch real inventory products from backend
  const fetchProducts = async () => {
    setIsLoadingProducts(true);
    setFetchError(null);
    try {
      const res = await apiFetchJson('/inventory/items');
      if (res.ok && Array.isArray(res.data?.items)) {
        setProducts(res.data.items);
      } else {
        setProducts([]);
        setFetchError(res.data?.message || 'Failed to fetch inventory from backend');
      }
    } catch (err) {
      setProducts([]);
      setFetchError(err.message || 'Server connection error');
    } finally {
      setIsLoadingProducts(false);
    }
  };

  // Fetch real customers from backend
  const fetchCustomers = async () => {
    try {
      const res = await getCustomers();
      if (res.ok && Array.isArray(res.data?.customers) && res.data.customers.length > 0) {
        setCustomerList([{ id: null, name: 'Walk-in Customer' }, ...res.data.customers]);
      } else {
        setCustomerList([{ id: null, name: 'Walk-in Customer' }]);
      }
    } catch {
      setCustomerList([{ id: null, name: 'Walk-in Customer' }]);
    }
  };

  useEffect(() => {
    fetchProducts();
    fetchCustomers();
  }, []);

  const catalog = products;


  const currentCart = useMemo(() => carts[activeCustomerIndex] || [], [carts, activeCustomerIndex]);
  const currentLabor = laborCharges[activeCustomerIndex] || 0;
  const currentPaid = paidAmounts[activeCustomerIndex] || '';

  // Subtotal, Tax, Total, Change calculations
  const subtotal = useMemo(() => {
    return currentCart.reduce((sum, item) => sum + (Number(item.price || item.sale_price) * item.qty), 0);
  }, [currentCart]);

  const taxAmount = useMemo(() => {
    const totalTax = currentCart.reduce((sum, item) => {
      const lineSub = Number(item.price || item.sale_price || 0) * item.qty;
      const lineTax = lineSub * (Number(item.tax_rate || 0) / 100);
      return sum + lineTax;
    }, 0);
    return Math.round(totalTax * 100) / 100;
  }, [currentCart]);

  const total = useMemo(() => {
    return Math.round((subtotal + taxAmount + Number(currentLabor)) * 100) / 100;
  }, [subtotal, taxAmount, currentLabor]);

  const changeDue = useMemo(() => {
    if (!currentPaid || Number(currentPaid) < total) return 0;
    return Math.round((Number(currentPaid) - total) * 100) / 100;
  }, [currentPaid, total]);

  // Real Barcode Lookup Handler (supports Camera & Hardware/Manual Scanner)
  const handleBarcodeLookup = async (barcodeVal) => {
    if (!barcodeVal || !barcodeVal.trim()) return;
    const cleanBarcode = barcodeVal.trim();
    setBarcodeScanError(null);
    setBarcodeScanSuccess(null);
    setScanLaserActive(true);

    try {
      const res = await scanBarcodeApi(cleanBarcode);
      if (res.ok && res.data?.item) {
        const matchedItem = res.data.item;
        const matchedVariant = matchedItem.matched_variant || null;
        addItemToCart(matchedItem, matchedVariant);
        setLastScannedItem(matchedItem);

        const displayName = matchedVariant && (matchedVariant.size || matchedVariant.color)
          ? `${matchedItem.name} (${[matchedVariant.size, matchedVariant.color].filter(Boolean).join('/')})`
          : matchedItem.name;

        setBarcodeScanSuccess(`Scanned & Added: ${displayName}`);
        setScanLaserActive(false);
        return true;
      } else {
        setBarcodeScanError(`Barcode not found: No active product or variant with barcode "${cleanBarcode}" exists in this shop.`);
        setScanLaserActive(false);
        return false;
      }
    } catch (err) {
      setBarcodeScanError(err.message || `No active product or variant with barcode "${cleanBarcode}" exists in this shop.`);
      setScanLaserActive(false);
      return false;
    }
  };

  const handleManualBarcodeSubmit = (e) => {
    e.preventDefault();
    if (manualBarcode.trim()) {
      handleBarcodeLookup(manualBarcode);
      setManualBarcode('');
    }
  };

  // Add item to cart helper with stock check
  const addItemToCart = (product, selectedVariant = null) => {
    const variant = selectedVariant || product.matched_variant || null;
    const prodId = Number(product.id);
    const varId = variant ? Number(variant.id) : null;
    const itemKey = varId ? `${prodId}-v${varId}` : `${prodId}`;

    const prodName = variant && (variant.size || variant.color)
      ? `${product.name} (${[variant.size, variant.color].filter(Boolean).join(' / ')})`
      : product.name;

    const prodPrice = Number(variant ? (variant.sale_price || product.sale_price || product.price || 0) : (product.sale_price ?? product.price ?? 0));
    const prodStock = Number(variant ? variant.stock_quantity : (product.stock_quantity ?? product.stock ?? 9999));
    const prodTaxRate = Number(product.tax_rate ?? product.taxRate ?? product.module_specific_fields?.tax_rate ?? 0);

    if (prodStock <= 0) {
      alert(`Cannot add "${prodName}": Out of Stock.`);
      return;
    }

    setCarts((prev) => {
      const activeCart = prev[activeCustomerIndex] || [];
      const existingItemIndex = activeCart.findIndex((item) => (item.key ? item.key === itemKey : (item.id === prodId && item.variantId === varId)));

      let newCart;
      if (existingItemIndex >= 0) {
        const currentQty = activeCart[existingItemIndex].qty;
        if (currentQty + 1 > prodStock) {
          alert(`Cannot add more than available stock (${prodStock} units).`);
          return prev;
        }
        newCart = activeCart.map((item, idx) =>
          idx === existingItemIndex ? { ...item, qty: item.qty + 1 } : item
        );
      } else {
        newCart = [...activeCart, {
          key: itemKey,
          id: prodId,
          variantId: varId,
          name: prodName,
          price: prodPrice,
          stock: prodStock,
          tax_rate: prodTaxRate,
          qty: 1
        }];
      }

      return {
        ...prev,
        [activeCustomerIndex]: newCart,
      };
    });
  };

  // Update item qty in cart with stock check
  const updateQty = (itemKeyOrId, newQty) => {
    setCarts((prev) => {
      const activeCart = prev[activeCustomerIndex] || [];
      const item = activeCart.find((i) => i.key === itemKeyOrId || i.id === itemKeyOrId);
      if (item && newQty > item.stock) {
        alert(`Maximum stock available for "${item.name}" is ${item.stock} units.`);
        return prev;
      }

      const updated = activeCart.map((item) =>
        (item.key === itemKeyOrId || item.id === itemKeyOrId) ? { ...item, qty: Math.max(0.001, Number(newQty)) } : item
      );
      return {
        ...prev,
        [activeCustomerIndex]: updated,
      };
    });
  };

  // Remove item from cart
  const removeItem = (itemKeyOrId) => {
    setCarts((prev) => {
      const activeCart = prev[activeCustomerIndex] || [];
      const updated = activeCart.filter((item) => item.key !== itemKeyOrId && item.id !== itemKeyOrId);
      return {
        ...prev,
        [activeCustomerIndex]: updated,
      };
    });
  };

  // Clear current cart/inputs
  const handleClear = () => {
    setCarts((prev) => ({ ...prev, [activeCustomerIndex]: [] }));
    setLaborCharges((prev) => ({ ...prev, [activeCustomerIndex]: 0 }));
    setPaidAmounts((prev) => ({ ...prev, [activeCustomerIndex]: '' }));
    setLastScannedItem(null);
    setCheckoutError(null);
  };

  // Real Checkout Handler
  const handleCheckout = async () => {
    if (!currentCart || currentCart.length === 0) {
      alert('Cart is empty! Please add products before check out.');
      return;
    }

    const paidVal = Number(currentPaid);
    if (!currentPaid || isNaN(paidVal) || paidVal < total) {
      alert(`Paid amount must be at least the total amount (Rs. ${total}).`);
      return;
    }

    setIsSubmitting(true);
    setCheckoutError(null);

    try {
      const selectedCust = customerList[activeCustomerIndex];
      const res = await createSale({
        customerId: selectedCust?.id || null,
        items: currentCart.map((item) => ({
          productId: Number(item.id),
          variantId: item.variantId ? Number(item.variantId) : undefined,
          quantity: Number(item.qty),
          discountAmount: 0,
        })),
        payment: {
          method: 'cash',
          amount: paidVal,
        },
        note: selectedCust?.id ? `Customer: ${selectedCust.name}` : 'Walk-in Customer - POS Sale',
      });

      if (!res.ok) {
        throw new Error(res.data?.message || 'Checkout failed');
      }

      // Success
      setCompletedSale(res.data.sale);
      handleClear();
      fetchProducts(); // Refresh real inventory stock
    } catch (err) {
      setCheckoutError(err.message);
      alert(`Checkout Rejected: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };


  // Filter products based on search query
  const filteredProducts = useMemo(() => {
    if (!searchQuery.trim()) return [];
    return catalog.filter((p) =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery, catalog]);

  return (
    <div className="flex h-screen w-full overflow-hidden bg-[#efe9c4] text-[#0f2e13] font-sans">
      <div className="flex flex-1 flex-col overflow-y-auto px-4 py-3 sm:px-6 sm:py-4">
        {/* Header Section */}
        <header className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-4">
          {/* Logo Brand left */}
          <div className="flex items-center select-none">
            <img 
              src={displayLogo} 
              alt="Store Logo" 
              className="w-32 sm:w-40 h-auto object-contain max-h-16 md:max-h-20" 
            />
          </div>

          {/* Center Store Title */}
          <div className="flex flex-col items-center">
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-wide text-center uppercase" style={{ color: 'var(--color-primary)' }}>
              {displayShopName}
            </h1>
            <div className="flex gap-1.5 mt-0.5">
              <span className="w-1.5 h-1.5 rounded-full animate-ping" style={{ backgroundColor: 'var(--color-accent)' }} />
              <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: 'var(--color-accent)' }} />
              <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: 'var(--color-accent)' }} />
            </div>
          </div>

          {/* Right Clock and Login */}
          <div className="flex items-center gap-4">
            <div className="text-right hidden md:block">
              <POSClock />
            </div>
            <button
              onClick={() => navigate('/admin-login')}
              className="text-[#efe9c4] text-xs font-extrabold px-4 py-2.5 rounded-full transition-all duration-200 tracking-wider cursor-pointer active:scale-95 shadow-md"
              style={{ backgroundColor: 'var(--color-primary)' }}
            >
              ADMIN LOGIN
            </button>
          </div>
        </header>

        {/* Error / Empty State Banners */}
        {fetchError && (
          <div className="w-full p-3 mb-4 bg-red-100 border border-red-300 text-red-800 rounded-xl text-xs font-bold flex justify-between items-center">
            <span>Error loading products from server: {fetchError}</span>
            <button onClick={fetchProducts} className="underline font-extrabold cursor-pointer">Retry</button>
          </div>
        )}

        {!fetchError && !isLoadingProducts && products.length === 0 && (
          <div className="w-full p-3 mb-4 bg-amber-100 border border-amber-300 text-amber-900 rounded-xl text-xs font-bold text-center">
            No products available in inventory. Please add products from Admin Inventory.
          </div>
        )}

        {/* Search Bar section */}
        <div className="relative w-full mb-4">
          <div className="flex items-center bg-white rounded-full px-4 py-3 border border-[#ca8a04]/30 shadow-sm focus-within:ring-2 focus-within:ring-[#0d3410]/20 transition-all">
            <input
              type="text"
              placeholder="Search products by name or scan barcode..."
              className="w-full text-sm outline-none text-[#0d3410] placeholder-[#0d3410]/50 pr-4"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setShowSearchResults(true);
              }}
              onFocus={() => setShowSearchResults(true)}
            />
            <Search className="text-[#0d3410]/70 w-5 h-5 shrink-0" />
          </div>

          {/* Search Dropdown Popover */}
          {showSearchResults && filteredProducts.length > 0 && (
            <div className="absolute left-0 right-0 mt-1 bg-white rounded-xl shadow-lg border border-[#ca8a04]/20 z-50 max-h-60 overflow-y-auto">
              {filteredProducts.map((product) => (
                <button
                  key={product.id}
                  onClick={() => {
                    addItemToCart(product);
                    setSearchQuery('');
                    setShowSearchResults(false);
                  }}
                  className="w-full text-left px-4 py-3 hover:bg-[#efe9c4]/40 flex justify-between items-center border-b border-gray-100 last:border-b-0 text-sm font-semibold transition-colors"
                >
                  <span className="text-[#0d3410]">{product.name}</span>
                  <span className="text-[#ca8a04]">Rs. {product.sale_price ?? product.price}</span>
                </button>
              ))}
            </div>
          )}

          {showSearchResults && searchQuery && filteredProducts.length === 0 && (
            <div className="absolute left-0 right-0 mt-1 bg-white rounded-xl shadow-lg border border-red-200 p-4 text-center text-sm font-medium text-red-600 z-50">
              No products found matching "{searchQuery}"
            </div>
          )}
        </div>

        {/* Customer tabs bar */}
        <div className="flex flex-wrap gap-2.5 mb-4">
          {customerList.map((cust, idx) => {
            const isActive = activeCustomerIndex === idx;
            return (
              <button
                key={cust.id ?? `walkin-${idx}`}
                onClick={() => setActiveCustomerIndex(idx)}
                className={`px-6 py-2.5 rounded-xl text-xs md:text-sm font-bold transition-all duration-200 ${
                  isActive ? 'text-white shadow-md' : 'bg-transparent border hover:opacity-80'
                }`}
                style={
                  isActive
                    ? { backgroundColor: 'var(--color-primary)' }
                    : { color: 'var(--color-primary)', borderColor: 'var(--color-primary)' }
                }
              >
                {cust.name}
              </button>
            );
          })}
        </div>

        {/* Barcode Feedback Notifications */}
        {barcodeScanSuccess && (
          <div className="w-full p-3 mb-4 bg-emerald-100 border border-emerald-300 text-emerald-900 rounded-xl text-xs font-bold flex justify-between items-center animate-in fade-in">
            <span>{barcodeScanSuccess}</span>
            <button onClick={() => setBarcodeScanSuccess(null)} className="text-emerald-800 hover:text-emerald-950 font-extrabold cursor-pointer">✕</button>
          </div>
        )}
        {barcodeScanError && (
          <div className="w-full p-3 mb-4 bg-red-100 border border-red-300 text-red-900 rounded-xl text-xs font-bold flex justify-between items-center animate-in fade-in">
            <span>{barcodeScanError}</span>
            <button onClick={() => setBarcodeScanError(null)} className="text-red-800 hover:text-red-950 font-extrabold cursor-pointer">✕</button>
          </div>
        )}

        {/* Main interactive grid section */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          {/* Left panel: Barcode Scanner & Hardware Input */}
          <div className="lg:col-span-7 bg-white rounded-3xl border border-gray-100 p-6 flex flex-col items-center justify-between min-h-[460px] shadow-sm relative overflow-hidden">
            {/* Top Right Scanned items badge */}
            <div className="absolute top-4 right-4 text-[11px] md:text-xs font-bold px-3 py-1.5 rounded-full select-none" style={{ backgroundColor: 'var(--color-light)', color: 'var(--color-primary)' }}>
              {currentCart.reduce((sum, item) => sum + item.qty, 0)} items scanned
            </div>

            {/* Scanner visualization */}
            <div className="my-4 relative flex flex-col items-center justify-center w-full max-w-[280px] h-[160px] border-2 border-dashed border-gray-200 rounded-2xl bg-gray-50/50 p-4 transition-all">
              {/* Target brackets */}
              <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-gray-400" />
              <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-gray-400" />
              <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-gray-400" />
              <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-gray-400" />

              {/* Barcode Graphic using Lucide */}
              <Barcode className="w-32 h-20 text-gray-800" />

              {/* Animated laser line */}
              <div
                className={`absolute left-0 right-0 h-0.5 bg-red-500 shadow-[0_0_8px_#ef4444] transition-all duration-500 ${scanLaserActive ? 'opacity-100 top-1/2 translate-y-[-50%] scale-x-95' : 'opacity-30 top-10 scale-x-90'
                  }`}
              />
            </div>

            {/* Instruction labels & Actions */}
            <div className="text-center mb-3 w-full max-w-sm flex flex-col items-center gap-3">
              <div>
                <h3 className="text-base md:text-lg font-bold text-gray-900">Scan Barcode / Enter Manually</h3>
                <p className="text-xs text-gray-500 mt-0.5">Use camera or hardware USB barcode reader</p>
              </div>

              {/* Camera Scanner Trigger */}
              <button
                type="button"
                onClick={() => setIsScannerOpen(true)}
                disabled={scanLaserActive}
                className={`w-full py-2.5 text-[#efe9c4] text-xs md:text-sm font-extrabold rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer ${scanLaserActive ? 'opacity-70 cursor-not-allowed' : 'hover:opacity-90'}`}
                style={{ backgroundColor: 'var(--color-primary)' }}
              >
                <Barcode size={18} /> Scan next item
              </button>

              {/* Hardware Scanner / Manual Barcode Input Form */}
              <form onSubmit={handleManualBarcodeSubmit} className="w-full flex gap-2">
                <input
                  type="text"
                  placeholder="Enter barcode or scan here..."
                  value={manualBarcode}
                  onChange={(e) => setManualBarcode(e.target.value)}
                  className="flex-1 bg-gray-50 border border-gray-300 rounded-xl px-3.5 py-2 text-xs font-bold text-[#0d3410] outline-none focus:border-[#0d3410] focus:bg-white"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#0d3410] text-white text-xs font-bold rounded-xl hover:bg-[#114720] transition cursor-pointer"
                >
                  Lookup
                </button>
              </form>
            </div>

            {/* Footer scanned list */}
            <div className="w-full mt-4 pt-3 border-t border-gray-100 text-center">
              <p className="text-[10px] font-extrabold tracking-wider text-gray-400 mb-1 uppercase">
                SCANNED SO FAR
              </p>
              {lastScannedItem ? (
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-green-50 rounded-full text-xs font-semibold text-green-700 animate-fade-in">
                  <span>Scanned: {lastScannedItem.name}</span>
                  <span className="text-[10px] bg-green-200 text-green-800 px-1.5 py-0.5 rounded-full">
                    Rs. {lastScannedItem.sale_price ?? lastScannedItem.price}
                  </span>
                </div>
              ) : (
                <span className="text-xs text-gray-400">No items scanned yet in this session</span>
              )}
            </div>
          </div>

          {/* Right panel: Bill preview and table */}
          <div className="lg:col-span-5 flex flex-col">
            {/* Header banner with active theme */}
            <div className="rounded-t-2xl px-4 py-3 flex items-center justify-between text-white shadow-sm select-none" style={{ backgroundColor: 'var(--color-primary)' }}>
              <span className="text-sm md:text-base font-bold font-mono tracking-wide">POS Checkout</span>
              <div className="flex gap-2">
                <button
                  onClick={handleClear}
                  className="bg-white hover:bg-white/90 text-[11px] md:text-xs font-bold px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1"
                  style={{ color: 'var(--color-primary)' }}
                >
                  <Trash2 size={12} />
                  Clear
                </button>
              </div>
            </div>

            {/* Bill body */}
            <div className="bg-white rounded-b-2xl border-x border-b border-gray-200/80 p-4 flex flex-col justify-between shadow-sm min-h-[400px]">
              {/* Table section */}
              <div className="flex-1 overflow-y-auto mb-4 max-h-[220px]">
                <table className="w-full text-left">
                  <thead>
                    <tr className="text-[10px] md:text-xs font-bold tracking-wider text-gray-400 border-b border-gray-100 uppercase">
                      <th className="pb-2 font-extrabold w-3/5">Item Name</th>
                      <th className="pb-2 font-extrabold text-center w-1/5">QTY</th>
                      <th className="pb-2 font-extrabold text-right w-1/5">PRICE</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {currentCart.length > 0 ? (
                      currentCart.map((item) => (
                        <tr key={item.id} className="text-xs md:text-sm font-semibold text-gray-800">
                          <td className="py-2.5 pr-2">
                            <div>
                              <p className="truncate max-w-[160px] sm:max-w-[200px]">{item.name}</p>
                              <button
                                onClick={() => removeItem(item.id)}
                                className="text-[10px] md:text-xs text-red-500 hover:text-red-700 font-bold mt-0.5 block"
                              >
                                Remove
                              </button>
                            </div>
                          </td>
                          <td className="py-2.5 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                onClick={() => updateQty(item.id, item.qty - 1)}
                                className="w-5 h-5 flex items-center justify-center rounded bg-gray-100 text-gray-600 hover:bg-gray-200"
                              >
                                -
                              </button>
                              <span className="w-4 text-center font-bold text-sm">{item.qty}</span>
                              <button
                                onClick={() => updateQty(item.id, item.qty + 1)}
                                className="w-5 h-5 flex items-center justify-center rounded bg-gray-100 text-gray-600 hover:bg-gray-200"
                              >
                                +
                              </button>
                            </div>
                          </td>
                          <td className="py-2.5 text-right font-mono">
                            Rs. {item.price * item.qty}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={3} className="py-12 text-center text-xs text-gray-400 font-medium">
                          No items in invoice yet
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Calculation Summary block */}
              <div className="border-t border-gray-100 pt-4 space-y-3">
                {/* Subtotal row */}
                <div className="flex justify-between items-center text-xs md:text-sm font-bold text-gray-600">
                  <span>Subtotal</span>
                  <span className="font-mono text-gray-900">Rs. {subtotal}</span>
                </div>

                {/* Tax row */}
                {taxAmount > 0 && (
                  <div className="flex justify-between items-center text-xs md:text-sm font-bold text-gray-600">
                    <span>Tax</span>
                    <span className="font-mono text-gray-900">Rs. {taxAmount}</span>
                  </div>
                )}

                {/* Labor Charges input */}
                <div className="flex justify-between items-center text-xs md:text-sm font-bold text-gray-600">
                  <span>Labor charges</span>
                  <div className="flex items-center gap-1.5 bg-[#f5f2db] px-2 py-1 rounded-lg border border-gray-200">
                    <span className="text-[10px] md:text-xs text-gray-500">Enter Rs.</span>
                    <input
                      type="number"
                      className="w-16 bg-transparent text-right font-mono outline-none font-bold text-[#0d3410]"
                      value={currentLabor || ''}
                      placeholder="0"
                      onChange={(e) => {
                        const val = e.target.value ? Math.max(0, parseInt(e.target.value)) : 0;
                        setLaborCharges((prev) => ({
                          ...prev,
                          [activeCustomerIndex]: val,
                        }));
                      }}
                    />
                  </div>
                </div>

                {/* Total bold row */}
                <div className="flex justify-between items-center pt-1.5 border-t border-dashed border-gray-100">
                  <span className="text-sm md:text-base font-extrabold" style={{ color: 'var(--color-primary)' }}>Total</span>
                  <span className="text-base md:text-lg font-extrabold font-mono" style={{ color: 'var(--color-primary)' }}>
                    Rs. {total}
                  </span>
                </div>

                {/* Paid Amount input */}
                <div className="flex justify-between items-center text-xs md:text-sm font-bold text-gray-600">
                  <span>Paid amount</span>
                  <div className="flex items-center gap-1.5 bg-[#f5f2db] px-2 py-1 rounded-lg border border-gray-200">
                    <span className="text-[10px] md:text-xs text-gray-500">Enter Rs.</span>
                    <input
                      type="number"
                      className="w-16 bg-transparent text-right font-mono outline-none font-bold text-[#0d3410]"
                      value={currentPaid}
                      placeholder="0"
                      onChange={(e) => {
                        const val = e.target.value;
                        setPaidAmounts((prev) => ({
                          ...prev,
                          [activeCustomerIndex]: val,
                        }));
                      }}
                    />
                  </div>
                </div>

                {/* Change row */}
                <div className="flex justify-between items-center text-xs md:text-sm font-bold text-gray-600">
                  <span>Change</span>
                  <span className="font-mono text-gray-900">Rs. {changeDue}</span>
                </div>

                {/* Action buttons at bottom */}
                <div className="grid grid-cols-2 gap-3 pt-3 border-t border-gray-100">
                  <button
                    onClick={handleCheckout}
                    disabled={isSubmitting || currentCart.length === 0}
                    className={`w-full py-3 text-white rounded-xl text-xs md:text-sm font-extrabold tracking-wide uppercase transition-colors ${
                      isSubmitting || currentCart.length === 0 ? 'opacity-50 cursor-not-allowed' : ''
                    }`}
                    style={{ backgroundColor: 'var(--color-primary)' }}
                  >
                    {isSubmitting ? 'Processing...' : 'Save & Checkout'}
                  </button>
                  <button
                    onClick={() => {
                      window.print();
                    }}
                    className="w-full py-3 border rounded-xl text-xs md:text-sm font-extrabold tracking-wide uppercase transition-colors"
                    style={{ borderColor: 'var(--color-primary)', color: 'var(--color-primary)' }}
                  >
                    Print
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Server Authoritative Receipt Modal */}
      {completedSale && (
        <ViewInvoiceModal
          invoice={completedSale}
          onClose={() => setCompletedSale(null)}
        />
      )}

      {/* Camera Barcode Scanner Modal */}
      <BarcodeScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScan={(scannedCode) => {
          handleBarcodeLookup(scannedCode);
        }}
      />
    </div>
  );
}
